package crud_Operations;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Get_request_queryparam {
	
	public void queryparam() {
		
		
		//Get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Adding Authentication
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		//construct Request
		RequestSpecification input=RestAssured.given()
				.accept("Application/json")
				.queryParam("sysparm_fields","short_description, sys_id")
				.queryParam("sysparm_limit", "1");
		
		//send Request
		Response response=input.get("/change_request");
		
		//get status code
		//System.out.println(response.getStatusCode());
		System.out.println(response.statusCode());
		
		//print Response
		response.prettyPrint();
		
	}

}
