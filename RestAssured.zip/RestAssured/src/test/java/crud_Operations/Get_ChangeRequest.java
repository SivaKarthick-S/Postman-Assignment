package crud_Operations;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Get_ChangeRequest {
	@Test
	public void getChange() {
		
		//Get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Adding Authentication
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		//construct Request
		RequestSpecification input=RestAssured.given().accept("Application/json");
		
		//send Request
		Response response=input.get("/change_request");
		
		//get status code
		System.out.println(response.getStatusCode());
		
		//print Response
		response.prettyPrint();
		
	}

}
