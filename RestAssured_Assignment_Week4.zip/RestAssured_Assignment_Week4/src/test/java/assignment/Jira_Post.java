package assignment;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Jira_Post {
	@Test
	public void Post(){
		
		//Get the Endpoint
		RestAssured.baseURI="https://postmanjan23.atlassian.net/rest/api/2/issue/";
		
		//Add Authentication
		RestAssured.authentication=RestAssured.preemptive().basic("sivakarthickeyan142@gmail.com", "ATATT3xFfGF0gZ1l8OVh6hlI0I36qeDflB5-1gG9jvyfchohxoO2nwD7OJTsGPqtQfZzsYq3p_fGNKVBY0qQy6TQo_C3ze7W3bTglri-WsdBNnyr8hDyFEPCttyghMk_Z9xZ9HtRlc7JGpDC-2nJhjqHFrnqVo0gh4TJ5RGEwQbR0Qy_K78p5Os=4B47B470");
		
		//construct request
	RequestSpecification input=	RestAssured.given().contentType("Application/json").body("{\r\n"
			+ "    \"fields\": {\r\n"
			+ "        \"project\": {\r\n"
			+ "            \"key\": \"TES\"\r\n"
			+ "        },\r\n"
			+ "        \"summary\": \"create issue in Testleaf\",\r\n"
			+ "        \"description\": \"Creating of an issue using project keys and Resolve it fastly\",\r\n"
			+ "        \"issuetype\": {\r\n"
			+ "            \"name\": \"Bug\"\r\n"
			+ "        }\r\n"
			+ "    }\r\n"
			+ "}");
	
	//Send Request
	Response response=input.post();
	
	//get the statuscode
	System.out.println(response.getStatusCode());
	
	//get response
	response.prettyPrint();
			
	}

}
