package assignment;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Jira_Get {
	@Test
	public void getJira() {
		
		//get endpoint
		RestAssured.baseURI="https://postmanjan23.atlassian.net/rest/api/2/issue/";
		
		//Add Authentication
		RestAssured.authentication=RestAssured.preemptive().basic("sivakarthickeyan142@gmail.com", "ATATT3xFfGF0gZ1l8OVh6hlI0I36qeDflB5-1gG9jvyfchohxoO2nwD7OJTsGPqtQfZzsYq3p_fGNKVBY0qQy6TQo_C3ze7W3bTglri-WsdBNnyr8hDyFEPCttyghMk_Z9xZ9HtRlc7JGpDC-2nJhjqHFrnqVo0gh4TJ5RGEwQbR0Qy_K78p5Os=4B47B470");
		
		//construct request
	RequestSpecification input=	RestAssured.given().accept("application/json");
	
	//send request
	Response response=input.get("10029");
	
	//get statuscode
	System.out.println(response.getStatusCode());
	
	//get response
	response.prettyPrint();
	
	
	}

}
