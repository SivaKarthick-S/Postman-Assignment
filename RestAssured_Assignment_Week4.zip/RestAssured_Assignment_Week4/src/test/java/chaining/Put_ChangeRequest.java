package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Put_ChangeRequest extends Baseclass {
	
	
	
	@Test(dependsOnMethods = "chaining.Createchangerequest.create")
	public void put() {
		
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		RequestSpecification input=RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
				+ "    \"short_description\": \"hemcrest\"\r\n"
				+ "}");
		Response response=input.put("/change_request/"+sysid);
		
		response.then().assertThat().statusCode(200);
		response.then().log().all();
	}

}
