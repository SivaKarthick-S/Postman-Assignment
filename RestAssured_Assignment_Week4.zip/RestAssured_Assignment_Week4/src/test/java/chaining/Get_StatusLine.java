package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Get_StatusLine extends Baseclass {
	
	
	@Test(dependsOnMethods = "chaining.Using_Patch.Patch")
	public void status_line() {
		
		//Get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Add auth
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		//construct request
		RequestSpecification input=RestAssured.given().log().all();
		
		//send request
		Response response=input.delete("/change_request/"+sysid);
		
		//get the response
		response.then().assertThat().statusLine("HTTP/1.1 204 No Content");
		response.then().log().all();
	}

}
