package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class UpdateRequest extends Baseclass {
	
	@Test(dependsOnMethods = "chaining.Createchangerequest.create")
	public void Update() {
		
		input=RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
				+ "    \"short_description\":\"Kohli's Redemption is Awesome\",\r\n"
				+ "    \"description\":\"Siraj Comeback in ODI's\"\r\n"
				+ "}");
		response=input.put("/change_request/"+sysid);
		response.then().assertThat().statusCode(200);
	
	}

}
