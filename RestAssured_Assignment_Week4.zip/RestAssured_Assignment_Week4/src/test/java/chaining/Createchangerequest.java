package chaining;

import org.testng.annotations.Test;

public class Createchangerequest extends Baseclass {
	
	@Test
	public void create() {
		response=input.post("/change_request");
		sysid=response.jsonPath().getString("result.sys_id");
		System.out.println("Sysid is ==="+sysid);
		response.then().assertThat().statusCode(201);
	}

}
