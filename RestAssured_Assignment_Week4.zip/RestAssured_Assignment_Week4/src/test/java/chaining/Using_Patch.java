package chaining;

import org.hamcrest.Matchers;
import org.hamcrest.collection.HasItemInArray;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Using_Patch extends Baseclass {
	
	
	@Test(dependsOnMethods = "chaining.Put_ChangeRequest.put")
	public void Patch() {
		
		//Get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Add Auth
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		//construct request
	    RequestSpecification input=RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
	    		+ "    \"short_description\": \"hemcrest\"\r\n"
	    		+ "}");
	    
	    Response response=input.patch("/change_request/"+sysid);
	    
	    response.then().assertThat().body("result.short_description", Matchers.containsString("hemcrest"));
	    
	    response.then().assertThat().statusCode(200);
	    response.then().log().all();
		
		}

}
