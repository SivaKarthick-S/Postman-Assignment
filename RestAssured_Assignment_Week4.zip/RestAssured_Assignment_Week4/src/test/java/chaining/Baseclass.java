package chaining;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Baseclass {
	
	static RequestSpecification input;
	static String sysid;
	static Response response;
	
	
	@BeforeMethod
	public void setup() {
		
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		RestAssured.authentication=RestAssured.basic("admin","Hz4Pl^yAS+g0");
		
		 input=RestAssured.given().contentType(ContentType.JSON).log().all();
	}
		
		@AfterMethod
		public void exit() {
			response.then().log().all();
		}


}
