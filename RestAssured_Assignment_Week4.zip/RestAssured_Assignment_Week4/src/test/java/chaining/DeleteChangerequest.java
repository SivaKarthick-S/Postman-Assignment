package chaining;

import org.testng.annotations.Test;

public class DeleteChangerequest extends Baseclass {
	@Test(dependsOnMethods = "chaining.UpdateRequest.Update")
	public void cancel(){
		
		response=input.delete("/change_request/"+sysid);
		response.then().assertThat().statusCode(204);
	}

}
