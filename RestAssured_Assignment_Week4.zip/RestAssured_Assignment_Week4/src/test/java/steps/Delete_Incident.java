package steps;

import org.hamcrest.Matchers;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Delete_Incident extends Base_Class {
	
	
	@When("send the request Del")
	public void Del() {
		
		response=input.delete("/incident/"+systemid);
	}
	@Then("validate the response Del")
	public void mes() {
		response.then().assertThat().statusCode(204);
		response.then().assertThat().statusLine("HTTP/1.1 204 No Content").log().all();
		
		
	}

}
