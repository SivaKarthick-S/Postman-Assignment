package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ChangerequestWithQP {
	
		RequestSpecification input=null;
		Response response =null;
		
		@Given("get the Endpoint")
		public void Endpoint() {
			//Get the Endpoint
			RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		}
		
		@And("Add the Auth")
		public void Auth() {
		//Auth
			RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		}
		
		@And("Add the query param {string} and {string}")
		public void query(String Key, String value) {
			input=RestAssured.given().log().all();
			
			input.queryParam(Key, value).contentType(ContentType.JSON);
		}
		
		@When("send the request")
		public void request() {
			
			response=input.get("/change_request");
		}
		@Then("Validate the response")
		public void response() {
			
			response.then().assertThat().statusCode(200);
			response.then().log().all();
		}
}
