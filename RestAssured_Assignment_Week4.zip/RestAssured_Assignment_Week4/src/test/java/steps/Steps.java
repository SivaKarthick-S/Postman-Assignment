package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Steps {
	
	RequestSpecification input=null;
	Response response=null;
	
	@Given("Set the Endpoint")
	public void setEnd() {
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
	}
	@And("add the Auth")
	public void auth() {
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
	}
	@When("send Request")
	public void request() {
		input=RestAssured.given().log().all();
		response=input.get("/incidents");
	}
	@Then("validate the Response")
	public void response() {
		response.then().assertThat().statusCode(200);
		response.then().log().all();
	}
	

}
