package steps;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Base_Class {
	
	static RequestSpecification input;
	static Response response;
	static String systemid;

}
