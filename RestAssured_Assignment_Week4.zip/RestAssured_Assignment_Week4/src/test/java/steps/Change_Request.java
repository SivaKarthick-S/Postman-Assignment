package steps;

import org.hamcrest.Matchers;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Change_Request {
	 
	RequestSpecification input=null;
	Response response=null;
	
	@Given("set the Endpoint Cr")
	public void endpoint() {
		
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
	}
	
	@And("Add the Auth Cr")
	public void Auth() {
		
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
	}
	
	@When("^post the request with short_description as (.*) and category as (.*)$")
	public void post(String short_desc,String categ) {
		input=RestAssured.given().contentType(ContentType.JSON).body("{\"short_description\":\""+ short_desc +"\",\"category\":\""+ categ +"\"}");
	}
	
	@When("send the request Cr")
	public void request() {
		response=input.post("/change_request");
	}
	
	@Then("^validate the response Cr (.*) and (.*)$")
	public void valid(String short_desc,String categ) {
		response.then().assertThat().statusCode(201);
		response.then().log().all();
		response.then().assertThat().body("result.short_description", Matchers.containsString(short_desc));
		response.then().assertThat().body("result.category", Matchers.containsString(categ));
		System.out.println(response.body().jsonPath().getString("result.sys_id"));
	}
	
	
}
