package steps;

import org.hamcrest.Matchers;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Update_Incident extends Base_Class  {
	
	@When("post the request Chain")
	public void update() {
		
		input=RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
				+ "    \"short_description\": \"TamilNadu_606701\"\r\n"
				+ "}").log().all();
	}
		
		@When("send the request Up")
		public void ups() {
		response=input.put("/incident/"+systemid);
		}
		@Then("validate the response Up")
		public void con() {
		response.then().assertThat().statusCode(200);
		response.then().log().all();
		response.then().assertThat().body("result.short_description", Matchers.containsString("TamilNadu_606701"));
		}
	}



