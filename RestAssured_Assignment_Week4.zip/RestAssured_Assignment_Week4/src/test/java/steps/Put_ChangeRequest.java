package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Put_ChangeRequest {
	
	String sys_id="00378591078de1108a09f7108c1ed07b";
	RequestSpecification input=null;
	Response response=null;
	
	@Given("Set the Endpoint Update")
	public void End() {
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
	}
	
	@And("Add the Auth Update")
	public void Add() {
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
	}
	@When("^Post the request with short_description as (.*) and category as (.*)$")
	public void update(String shor,String cat) {
		
		input=RestAssured.given().contentType(ContentType.JSON).when().body("{\"short_description\":\""+ shor +"\",\"category\":\""+ cat +"\"}");
		
	}
	@When("Send the Request Update")
	public void reques() {
		
		response=input.put("/change_request/"+sys_id);
	}
	@Then("Validate the Response Update")
	public void vali() {
		
		response.then().assertThat().statusCode(200);
		response.then().log().all();
	}
	

}
