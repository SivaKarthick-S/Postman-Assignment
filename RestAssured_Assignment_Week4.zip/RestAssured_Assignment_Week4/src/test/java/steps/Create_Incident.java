package steps;

import hooks.Baseset;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Create_Incident extends Base_Class{
	
	
	
	@When("send the request Chain")
	public void manage() {
		
		input=RestAssured.given().contentType(ContentType.JSON).log().all();
		response=input.post("/incident");
		systemid=response.jsonPath().getString("result.sys_id");
		System.out.println("Sys_id is=="+systemid);
	}
		@Then("validate the response")
		public void check() {
		response.then().assertThat().statusCode(201);
	
		}
}
