package PracticeAPI;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Assertions {
	
	@Test
	public void asseriont() {
		
		//get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		RestAssured.authentication=RestAssured.basic("admin","Hz4Pl^yAS+g0");

		RequestSpecification input=RestAssured.given().contentType(ContentType.JSON);
		
		Response response=input.get("/incident");
		
		//response.then().assertThat().statusCode(202);
		
		response.then().assertThat().body("result[0].number", Matchers.equalTo("INC0010014"));
		
		
	}

}
