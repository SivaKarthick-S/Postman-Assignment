package PracticeAPI;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetMethod {
	@Test
	public void getrequest() {
		
		//Get endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		RestAssured.authentication=RestAssured.basic("admin","Hz4Pl^yAS+g0" );
		
		//construct request
		RequestSpecification input= RestAssured.given().contentType(ContentType.JSON);
		
		//send request
		Response response=input.post("/incident");
		
		//get the status code
		//System.out.println(response.getStatusCode());
		
		//print response
		//response.prettyPrint();
		response.then().assertThat().statusCode(201);
		
	}

}
