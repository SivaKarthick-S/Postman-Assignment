package PracticeAPI;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentwithFile {
	@Test
	public void incidentfile() {
		
		//Get Endpoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Authentication
		RestAssured.authentication=RestAssured.basic("admin","Hz4Pl^yAS+g0");
		
		//Parsing File
		File file= new File("./src/test/resources/data.json");
		
		RequestSpecification input=RestAssured.given().contentType(ContentType.JSON).body(file).log().all();
		
		Response response=input.post("/incident");
		
		System.out.println(response.statusCode());
		
		response.then().log().all();
		
		
	}

}
