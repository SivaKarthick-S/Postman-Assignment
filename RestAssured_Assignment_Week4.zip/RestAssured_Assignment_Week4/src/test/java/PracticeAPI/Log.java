package PracticeAPI;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Log {
	@Test
	public void logMethod() {
		
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		RestAssured.authentication=RestAssured.basic("admin","Hz4Pl^yAS+g0");
		
		RequestSpecification input=RestAssured.given().contentType(ContentType.JSON).log().all();
		
		Response reponse=input.get("/incident");
		
		reponse.then().log().all();
		
	}

}
