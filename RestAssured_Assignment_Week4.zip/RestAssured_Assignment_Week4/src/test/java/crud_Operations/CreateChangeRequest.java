package crud_Operations;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateChangeRequest {
	
	@Test
	public void getChangeRequest() {
		
		//Adding EndPoint
		RestAssured.baseURI="https://dev86113.service-now.com/api/now/table";
		
		//Adding Authentication
		RestAssured.authentication=RestAssured.basic("admin", "Hz4Pl^yAS+g0");
		
		//Construct Request
		RequestSpecification input=RestAssured.given().contentType("application/json").when().body("{\r\n"
				+ "    \"short_description\":\"Kohli's Redemption is Awesome\",\r\n"
				+ "    \"description\":\"Siraj Comeback in ODI's\"\r\n"
				+ "}");
		//Send Request
		Response response=input.post("/change_request");
		
		//Get Status Code
		System.out.println(response.getStatusCode());
		
		//print Response
		response.prettyPrint();
				

	}
}

